"""core layer."""
